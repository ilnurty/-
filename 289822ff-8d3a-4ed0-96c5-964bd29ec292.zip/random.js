function toggleExamples() {
  var examples = document.getElementById("examples");
  var portfolioText = document.getElementById("portfolioText");

  if (examples.style.display === "none") {
    examples.style.display = "block";
    portfolioText.style.display = "none";
  } else {
    examples.style.display = "none";
    portfolioText.style.display = "block";
  }
}

